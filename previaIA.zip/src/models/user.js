const mongoose = require('mongoose')

const UserSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
            trim: true
        },
        points: {
            type: Number,
            default: 0
        }
    },
    {
        timestamp: true
    }
)

module.exports = mongoose.model('User', UserSchema)