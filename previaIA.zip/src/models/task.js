const mongooose = require("mongoose")

const TaskSchema = new mongooose.Schema(
    {
        Title: {
            type: String,
            required: true,
            trim: true
        },
        completed: {
            type: Boolean,
            default: false
        },
        user: {
            type: mongoose.Schema.types.objectId,
            ref: 'User',
            required: true
        },
        points: {
            type: Number,
            default: 1
        }
    },
    {
        timestamps: true
    }
)

module.exports = mongoose.model('Task', TaskSchema)