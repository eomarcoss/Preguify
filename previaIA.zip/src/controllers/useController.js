const User = require('../models/user')


async function createUser(req, res){
    try{
        const {name} = req.body

        if(!name){
            return res.status(400).json({error: 'Nome é obrigatório'})
        }

        const user = await Userser.create({name})
    }
    catch(error){
        return res.status(500).json({error: 'Erro ao criar usuário'})
    }
}

module.exports = {createUser}