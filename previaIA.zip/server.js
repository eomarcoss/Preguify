const express = require("express");
const dotenv = require("dotenv")
dotenv.config()

//funcao de conexao com  o banco de dados
const connectDatabase = require("./src/database/connection");

//cria aplicacao express
const app = express();

const PORT = 3000;

//middleware para entender JSON
app.use(express.json());

connectDatabase();

//rota de teste
app.get("/", (req, res) => {
  res.send("api funcionando");
});

//inicia o servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
